package ro.ubbcj.cs.trias.ui;

public enum DataSource {
DATABASE, FILE
}
