package ro.ubbcj.cs.trias.io;

public enum FileType {
RDF, Holes, Standard
}
