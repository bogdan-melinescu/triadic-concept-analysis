package persistence;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/** 
 * Utility class for writing a specific file line by line.
 */
public class FilePrinter {

	private PrintWriter pw;

	public FilePrinter(String generatedFileName) {
		try {
			pw = new PrintWriter(new FileWriter(generatedFileName));
		} catch (IOException ex) {
			throw new RuntimeException("File error: " + ex);
		}
	}

	/**
	 * Writes a line formed by the parameters to the file
	 * @param id
	 * @param attr
	 * @param cond
	 * @param separator2
	 * the line is: id separator2 attr separator2 cond
	 */
	public void writeLine(String id, String attr, String cond, String separator2) {
		pw.println(id + separator2 + attr + separator2 + cond);
	}
	
	/** 
	 * Writes to the file the line given as parameter
	 * @param line
	 */
	public void writeLine(String line) {
		pw.println(line);
	}

	public void closePrinter() {
		pw.close();
	}

}
