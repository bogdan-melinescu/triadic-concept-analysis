package persistence;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;
import java.util.prefs.Preferences;

import model.DBConnectionInfo;

/**
 * Class for database operations. The queries retrieved from the context file
 * generated with Toscana suite will be run with the help of this utility class.
 */
public class DBOperations {

	private static final Preferences preferences = Preferences
			.userNodeForPackage(DBOperations.class);
	private final static Logger logger = Logger.getLogger(DBOperations.class
			.getName());
	private final static String EMBEDDED = "jdbc:hsqldb:.";

	private Connection connection;

	public DBOperations(DBConnectionInfo dbConnectionInfo) {

		try {
			connection = getConnection(dbConnectionInfo.getDbUrl(),
					dbConnectionInfo.getDbDriverClass(),
					dbConnectionInfo.getDbUsername(),
					dbConnectionInfo.getDbPassword(),
					dbConnectionInfo.getEmbeddedDatabaseLocation());

		} catch (Exception ex) {
			throw new RuntimeException("Database error: " + ex);
		}
	}

	/** Retrieves all the primary keys (=objects) from the given table */
	public List<String> getObjectsValues(String tableName, String primaryKey) {
		List<String> objectValues = new ArrayList<String>();
		String sqlString = "select " + primaryKey + " from " + tableName;
		try {
			PreparedStatement sql = (PreparedStatement) connection
					.prepareStatement(sqlString);
			ResultSet rs = (ResultSet) sql.executeQuery();
			while (rs.next()) {
				objectValues.add(rs.getString(primaryKey));
			}
		} catch (SQLException ex) {
			throw new RuntimeException("Database error: " + ex);
		}

		return objectValues;
	}

	/**
	 * Retrieves all the primary keys (=objects) from the given table which
	 * respect the specific conditions
	 */
	public List<String> getObjectsForCondition(String tableName,
			String primaryKey, String condition) {
		List<String> objectValues = new ArrayList<String>();
		String sqlString = "select " + primaryKey + " from " + tableName
				+ " where " + condition;
		try {
			PreparedStatement sql = (PreparedStatement) connection
					.prepareStatement(sqlString);
			ResultSet rs = (ResultSet) sql.executeQuery();
			while (rs.next()) {
				objectValues.add(rs.getString(primaryKey));
			}
		} catch (SQLException ex) {
			throw new RuntimeException("Database error: " + ex);
		}

		return objectValues;
	}

	/**
	 * Establishes a database connection
	 * 
	 * @param url
	 *            - the url for connecting to the database
	 * @param driverName
	 *            - the name of the database driver
	 * @param username
	 *            - the username for connection to the database
	 * @param password
	 *            - the password for connecting to the database
	 * @param embeddedDatabaseLocation
	 *            - the location where an sql script for the embedded database
	 *            is stored; if the database is not embedded this can be null
	 * @return
	 */
	private static Connection getConnection(String url, String driverName,
			String username, String password, String embeddedDatabaseLocation) {
		if ((url == null) || (url.equals(""))) {
			throw new RuntimeException(
					"No URL given for connecting to the database");
		}
		if ((driverName == null) || (driverName.equals(""))) {
			throw new RuntimeException(
					"No driver given for connecting to the database");
		}
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("Error loading database drivers");
		}

		Connection connection = null;

		// connect to the DB
		try {
			Properties connectionProperties = new Properties();
			connectionProperties.setProperty("user", username);
			connectionProperties.setProperty("password", password);
			connection = DriverManager.getConnection(url, connectionProperties);
			if (url.equals(EMBEDDED)) {
				executeScript(connection, embeddedDatabaseLocation);
			}
			logger.fine("Created new DB connection to " + url);
		} catch (SQLException ex) {
			throw new RuntimeException(ex);
		}
		return connection;
	}

	/**
	 * Loads an SQL script into the database.
	 */
	private static void executeScript(Connection connection, String sqlURL) {
		// we have to concatenate a couple of lines sometimes since the SQL
		// commands don't have to be on one line
		logger.fine(System.currentTimeMillis() + ": Submitting script: "
				+ sqlURL);
		String sqlCommand = "";
		try {
			BufferedReader in = new BufferedReader(new FileReader(sqlURL));
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				sqlCommand = (sqlCommand + inputLine).trim();
				if ((sqlCommand.length() != 0)
						&& sqlCommand.charAt(sqlCommand.length() - 1) == ';') {
					connection.createStatement().execute(sqlCommand);
					sqlCommand = "";
				}
			}
			in.close();
		} catch (Exception e) {
			throw new RuntimeException("Could not read SQL script from URL '"
					+ sqlURL.toString() + "'.", e);
		}
		logger.fine(System.currentTimeMillis() + ": done.");
	}
}
