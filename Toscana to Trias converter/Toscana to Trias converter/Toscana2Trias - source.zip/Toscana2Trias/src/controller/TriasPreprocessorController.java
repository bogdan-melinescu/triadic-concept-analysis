package controller;

import java.io.File;
import java.util.List;

import model.Diagram;
import model.ScalingInfo;
import net.sourceforge.toscanaj.model.ConceptualSchema;
import net.sourceforge.toscanaj.parser.CSXParser;

import org.tockit.events.EventBroker;

import persistence.DBOperations;
import service.OALFileGenerator;
import service.ScalesImporter;
import service.TriasFileGenerator;

/**
 * Controller for the graphical user interface which manipulates the creation of a triadic context
 */
public class TriasPreprocessorController {

	/** Name of the file from which the scales created with Elba are imported 
	 *  and also the DB connection and other common settings with the diadic approach
	 */
	private final static String SCHEMA_FILE_NAME = "schema.csx";

	/** Service class which imports the scales to local structures*/
	private ScalesImporter scalesImporter;

	/** Service class which creates the Trias-specific file for mining triadic concepts*/
	private TriasFileGenerator triasGenerator;
	/** Service class which creates the a Conexp-specific file for mining asociation/implications derived from the triadic context*/
	private OALFileGenerator oalGenerator;
	
	private String tableName, keyName;
	
	/** Persistence class which accesses the database */
	private DBOperations dbOperations;

	/** Constructor to initialize all service classes*/
	public TriasPreprocessorController() {
		scalesImporter = new ScalesImporter();
		triasGenerator = new TriasFileGenerator();
		oalGenerator = new OALFileGenerator();
		scalesImporter.importScales(SCHEMA_FILE_NAME);
		try {
			ConceptualSchema conceptualSchema = CSXParser.parse(
					new EventBroker(), new File(SCHEMA_FILE_NAME));
			tableName = conceptualSchema.getDatabaseInfo().getTable()
					.getDisplayName();
			keyName = conceptualSchema.getDatabaseInfo().getKey().getDisplayName();
			dbOperations = new DBOperations(scalesImporter.getDbInfo());
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	/** Imports the scales read from the schema file to local structures*/
	public List<Diagram> importScales() {
		return scalesImporter.getDiagrams();
	}

	/** Generates a file for Trias upload */
	public void generateTriasFile(List<ScalingInfo> selectedAttributes,
			List<ScalingInfo> selectedConditions, String separator,
			String outputFileName) {
		triasGenerator.generateFile(outputFileName, selectedAttributes,
				selectedConditions, this.dbOperations, this.tableName,
				this.keyName, separator);
	}

	/** Generates a file for Conexp upload*/
	public void generateOALFile(List<ScalingInfo> selectedAttributes,
			List<ScalingInfo> selectedConditions, String outputFileName) {
		oalGenerator.generateFile(outputFileName, selectedAttributes,
				selectedConditions, this.dbOperations, this.tableName,
				this.keyName);

	}

}
