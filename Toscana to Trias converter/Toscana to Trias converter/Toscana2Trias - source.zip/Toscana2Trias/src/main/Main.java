package main;

import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import ui.TriasUI;

public class Main {

	public static void main(String args[]) {
		
		TriasUI frame = new TriasUI();
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		frame.setVisible(true);
	}
}
