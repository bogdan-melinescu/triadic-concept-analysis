package service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.ScalingInfo;
import persistence.DBOperations;
import persistence.FilePrinter;

public class OALFileGenerator {

	/** File writer for the actual generation of the Trias specific file*/
	private FilePrinter writer;

	/**
	 * Method comprising the algorithm for generating am oal file from the user-selected scales
	 * @param generatedFileName - the output file
	 * @param selectedAttributes - the scales of the initial attributes which were selected by the user to 
	 * 							   form the <code>attributes set</code> in the triadic approach
	 * @param selectedConditions - the scales of the initial attributes which were selected by the user to 
	 * 							   form the <code>conditions set</code> in the triadic approach
	 * @param dao - the DBOprations class for accessing the database
	 * @param tableName - the base table name
	 * @param keyName - the primary key of the table (which represent the set of the objects in the triadic approach)
	 */
	public void generateFile(String generatedFileName,
			List<ScalingInfo> selectedAttributes,
			List<ScalingInfo> selectedConditions,
			DBOperations dao, String tableName, String keyName) {

		writer = new FilePrinter(generatedFileName);

		List<String> ids = dao.getObjectsValues(tableName, keyName);
		Map<String, List<String>> attrIds = computeIds(selectedAttributes, tableName, keyName, dao);
		Map<String, List<String>> condIds = computeIds(selectedConditions, tableName, keyName, dao);
		Map<DoubleString, List<String>> tripleMap = new HashMap<DoubleString, List<String>>();

		for (String id : ids) {
			for (String attr : attrIds.keySet()) {
				if (attrIds.get(attr).contains(id)) {
					DoubleString object = new DoubleString(proccessId(id), attr);
					List<String> listForObject = tripleMap.get(object);
					if (listForObject == null) {
						listForObject = new ArrayList<String>();
						tripleMap.put(object, listForObject);
					}
					for (String cond : condIds.keySet()) {
						if (condIds.get(cond).contains(id)) {
							listForObject.add(cond);
						}
					}
				}
			}
		}
		for (DoubleString obj : tripleMap.keySet()) {
			String line = obj + ":";
			for (String at : tripleMap.get(obj)) {
				line += at + ";";
			}
			line = line.substring(0, line.length() - 1);
			writer.writeLine(line);
		}

		writer.closePrinter();

	}

	private Map<String, List<String>> computeIds(List<ScalingInfo> selected, String tableName, String keyName, DBOperations dao) {
		Map<String, List<String>> result = new HashMap<String, List<String>>();
		for (ScalingInfo attr : selected) {
			List<String> ids = new ArrayList<String>();
			for (String whereClause : attr.getWhereClauses()) {
				ids.addAll(dao.getObjectsForCondition(tableName, keyName,
						whereClause));
			}
			result.put(attr.getLabel(), ids);
		}
		return result;
	}

	/** NON GENERAL!!!! */
	private String proccessId(String id) {
		int index = id.indexOf(".");
		id = id.substring(0, index);
		return id;
	}

	private class DoubleString {
		
		private String s1, s2;
		
		public DoubleString(String s1, String s2) {
			this.s1 = s1;
			this.s2 = s2;
		}
		
		public String toString() {
			return s1 + " x " + s2;
		}
		
		public int hashCode() {
			return s1.hashCode() + s2.hashCode();
		}
		
		public boolean equals(Object obj) {
			if (obj instanceof DoubleString) {
				return (((DoubleString) obj).s1.equals(this.s1) && (((DoubleString) obj).s2.equals(this.s2)));
			}
			else {
				return false;
			}
		}
	}

}
