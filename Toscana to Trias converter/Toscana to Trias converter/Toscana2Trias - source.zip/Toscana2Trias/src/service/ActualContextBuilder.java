package service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import model.Diagram;
import model.ScalingInfo;
import net.sourceforge.toscanaj.controller.fca.DiagramToContextConverter;
import net.sourceforge.toscanaj.model.context.FCAElement;
import net.sourceforge.toscanaj.model.diagram.Diagram2D;

import org.tockit.context.model.BinaryRelation;
import org.tockit.context.model.Context;
/**
 * Service class which imports a lot of the Toscana utilities to finally  
 * export the scales created in the Toscana suite
 */
@SuppressWarnings("all")
public class ActualContextBuilder {
 
	
	private List<Diagram> diagrams = new ArrayList<Diagram>();
	
	public ActualContextBuilder(Iterator diagramIterator) {
		parseAttributesAndObjectQueries(diagramIterator);
	}

	private void parseAttributesAndObjectQueries(Iterator diagramIterator) {
		for (Iterator iter = diagramIterator; iter.hasNext();) {
			
			Diagram2D diagram = (Diagram2D) iter.next();
			
			Diagram d = new Diagram();
			d.setDiagramTitle(diagram.getTitle());
			List<ScalingInfo> scales = new ArrayList<ScalingInfo>();
			
			Context svContext = DiagramToContextConverter.getContext(diagram);
			BinaryRelation relation = svContext.getRelation();
			
			for (Iterator attrIt = svContext.getAttributes().iterator(); attrIt.hasNext();) {
				FCAElement attribute = (FCAElement) attrIt.next();
				//System.out.println("Attribute: "+attribute.getData().toString());
				
				ScalingInfo scalingInfo = new ScalingInfo();
				scalingInfo.setLabel(attribute.getData().toString());
				
				for (Iterator objIt = svContext.getObjects().iterator(); objIt.hasNext();) {
					FCAElement object = (FCAElement) objIt.next();
					
					if (relation.contains(object, attribute)) {
						//System.out.println("Ojbect: "+object.getData().toString());
						scalingInfo.addWhereClause(object.getData().toString());
					}
				}
				scales.add(scalingInfo);
				d.putScale(scalingInfo.getLabel(), scalingInfo);
			}
			diagrams.add(d);
		}
	}

	public List<Diagram> getDiagrams() {
		return diagrams;
	}

	public void setDiagrams(List<Diagram> diagrams) {
		this.diagrams = diagrams;
	}

}
