package service;

import java.io.File;
import java.net.URL;
import java.util.List;

import model.DBConnectionInfo;
import model.Diagram;
import net.sourceforge.toscanaj.model.ConceptualSchema;
import net.sourceforge.toscanaj.parser.CSXParser;

import org.tockit.events.EventBroker;

/**
 * Service class which imports information from the context file generated 
 * by the Tosanca suite
 */
public class ScalesImporter {
	
	/** The scales read from Toscana grouped by the diagrams they are comprised in*/
	private List<Diagram> diagrams;
	
	/** The db connection settings used in the context file of Tosxana*/
	private DBConnectionInfo dbInfo;
		
	
	public ScalesImporter() {
		
	}

	/**
	 * Import scales and db connection parameters from the given files
	 * @param schemaFile - the file from which we import data
	 */
	public void importScales(String schemaFile){
		ConceptualSchema conceptualSchema;
		try {
			conceptualSchema = CSXParser.parse(new EventBroker(), new File(schemaFile));
			diagrams = retrieveScalesFromToscana(conceptualSchema); 
			dbInfo = retriveDBConnectionInfo(conceptualSchema);
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
		
	}
	
	/** Set into a local structure the DB connection parameters*/
	private DBConnectionInfo retriveDBConnectionInfo(
			ConceptualSchema conceptualSchema) {
		DBConnectionInfo dbConnectionInfo = new DBConnectionInfo();
		dbConnectionInfo.setDbDriverClass(conceptualSchema.getDatabaseInfo().getDriverClass());
	    dbConnectionInfo.setDbUrl(conceptualSchema.getDatabaseInfo().getURL());
	    dbConnectionInfo.setDbUsername(conceptualSchema.getDatabaseInfo().getUserName());
	    dbConnectionInfo.setDbPassword(conceptualSchema.getDatabaseInfo().getPassword());
	    URL embeddedDatabaseURL = conceptualSchema.getDatabaseInfo().getEmbeddedSQLLocation();
	    if (embeddedDatabaseURL != null) {
	    	dbConnectionInfo.setEmbeddedDatabaseLocation(conceptualSchema.getDatabaseInfo().getEmbeddedSQLLocation().getFile());
	    }
	    
		return dbConnectionInfo;
	}

	/** Set into a local structure the diagrams comprising the scales defined with Toscana suite*/
	private List<Diagram> retrieveScalesFromToscana(ConceptualSchema conceptualSchema) {
		try {
			ActualContextBuilder context = new ActualContextBuilder(conceptualSchema.getDiagramsIterator());
			return context.getDiagrams();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}


	public List<Diagram> getDiagrams() {
		return diagrams;
	}

	public void setDiagrams(List<Diagram> diagrams) {
		this.diagrams = diagrams;
	}

	
	public void setDbInfo(DBConnectionInfo dbInfo) {
		this.dbInfo = dbInfo;
	}

	public DBConnectionInfo getDbInfo() {
		return dbInfo;
	}


	
	

}
