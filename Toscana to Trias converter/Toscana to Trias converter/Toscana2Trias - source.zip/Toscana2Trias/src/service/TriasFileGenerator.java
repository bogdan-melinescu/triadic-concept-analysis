package service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import model.ScalingInfo;
import persistence.DBOperations;
import persistence.FilePrinter;

/**
 * Service class which holds the algorithm on the base of which the Trias specific file is generated
 */
public class TriasFileGenerator {

	/** File writer for the actual generation of the Trias specific file*/
	private FilePrinter writer;

	public TriasFileGenerator() {

	}

	/**
	 * Method comprising the algorithm for generating a Trias file from the user-selected scales
	 * @param generatedFileName - the output file
	 * @param selectedAttributes - the scales of the initial attributes which were selected by the user to 
	 * 							   form the <code>attributes set</code> in the triadic approach
	 * @param selectedConditions - the scales of the initial attributes which were selected by the user to 
	 * 							   form the <code>conditions set</code> in the triadic approach
	 * @param dao - the DBOprations class for accessing the database
	 * @param tableName - the base table name
	 * @param keyName - the primary key of the table (which represent the set of the objects in the triadic approach)
	 * @param separator - the separator used in the file generation
	 */
	public void generateFile(String generatedFileName,
			List<ScalingInfo> selectedAttributes,
			List<ScalingInfo> selectedConditions,
			DBOperations dao, String tableName,
			String keyName, String separator) {

		writer = new FilePrinter(generatedFileName);

		// retrieve all objects
		List<String> ids = dao.getObjectsValues(tableName, keyName);
		// retrieve all objects (through their ids) which obey the selected attributes
		Map<String, List<String>> attrIds = computeIds(selectedAttributes, tableName, keyName, dao);
		// retrieve all objects (through their ids) which obey the selected conditions
		Map<String, List<String>> condIds = computeIds(selectedConditions, tableName, keyName, dao);
		HashSet<Triple> tripleSet = new HashSet<Triple>();

		for (String id : ids) {
			for (String attr : attrIds.keySet()) {
				if (attrIds.get(attr).contains(id)) {
					for (String cond : condIds.keySet()) {
						if (condIds.get(cond).contains(id)) {
							/*in the initial case the id of an object was formed by two columns separated through "." although the natural objects
							 * were identified (not uniquely) by the part before ".". So in the file we will keep the natural form and 
							 * meaning of the identity of an object, not the one designed to represent a db suitable primary key.
							 * If your primary key is simple, identifies uniquely the object without the help
							 * of a second column, the remove the following line or replace it with
							 *  String processedId = id;  so you won't need to do any further modifications  
							*/
							String processedId = proccessId(id);
							tripleSet.add(new Triple(processedId, attr, cond));
						}
					}
				}
			}
		}
		for (Triple t : tripleSet) {
			writer.writeLine(t.getObj(), t.getAttr(), t.getCond(), separator);
		}

		writer.closePrinter();

	}
	
	/** Retrieves from the db the objects obeying the scales given as parameters*/
	private Map<String, List<String>> computeIds(List<ScalingInfo> selected, String tableName, String keyName, DBOperations dao) {
		Map<String, List<String>> result = new HashMap<String, List<String>>();
		for (ScalingInfo attr : selected) {
			List<String> ids = new ArrayList<String>();
			for (String whereClause : attr.getWhereClauses()) {
				ids.addAll(dao.getObjectsForCondition(tableName, keyName,
						whereClause));
			}
			result.put(attr.getLabel(), ids);
		}
		return result;
	}

	/** NON GENERAL!!!! */
	private String proccessId(String id) {
		int index = id.indexOf(".");
		id = id.substring(0, index);
		return id;
	}

	private class Triple {

		private String obj, attr, cond;

		public Triple(String obj, String attr, String cond) {
			this.obj = obj;
			this.attr = attr;
			this.cond = cond;
		}

		public String getAttr() {
			return attr;
		}

		public String getObj() {
			return obj;
		}

		public String getCond() {
			return cond;
		}

		public boolean equals(Object otherObject) {
			if (otherObject instanceof Triple) {
				Triple otherTriple = (Triple) otherObject;
				return (otherTriple.obj.equals(this.obj)
						&& otherTriple.attr.equals(this.attr) && otherTriple.cond
						.equals(this.cond));
			} else {
				return false;
			}
		}

		public int hashCode() {
			return obj.hashCode() + attr.hashCode() + cond.hashCode();
		}
	}

}
