package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Information for "a" scale
 */
public class ScalingInfo {

	/** Scale label (a nominal class of a certain attribute)*/
	private String label;
	
	/** The where clauses for the DB to map the attributes real value to the defined scales*/
	private List<String> whereClauses;
	
	public ScalingInfo(){
		setLabel("");
		whereClauses = new ArrayList<String>();
	}
	
	public void addWhereClause(String whereClause){
		whereClauses.add(whereClause);
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((label == null) ? 0 : label.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ScalingInfo other = (ScalingInfo) obj;
		if (label == null) {
			if (other.label != null)
				return false;
		} else if (!label.equals(other.label))
			return false;
		return true;
	}

	public List<String> getWhereClauses() {
		return whereClauses;
	}

	public void setWhereClauses(List<String> whereClauses) {
		this.whereClauses = whereClauses;
	}
	
	public String toString(){
		return label;
	}
	
	
}
