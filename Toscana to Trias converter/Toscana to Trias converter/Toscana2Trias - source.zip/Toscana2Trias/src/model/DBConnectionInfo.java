package model;

/**
 * DTO class holding information about the connection to the DB  
 *
 */
public class DBConnectionInfo {
	
	/** DB url */
	private String dbUrl;
	
	/** DB username*/
	private String dbUsername;
	
	/** DB password*/
	private String dbPassword;
	
	/** DB driver class*/
	private String dbDriverClass;
	
	/** embedded DB location*/
	private String embeddedDatabaseLocation;

	public DBConnectionInfo(){
		this.dbUrl = "";
		this.dbUsername = "";
		this.dbPassword = "";
		this.dbDriverClass = "";
		this.setEmbeddedDatabaseLocation("");
	}
	
	public DBConnectionInfo(String dbUrl, String dbUsername, String dbPassword,
			String dbDriverClass, String embeddedDatabaseLocation) {
		super();
		this.dbUrl = dbUrl;
		this.dbUsername = dbUsername;
		this.dbPassword = dbPassword;
		this.dbDriverClass = dbDriverClass;
		this.setEmbeddedDatabaseLocation(embeddedDatabaseLocation);
	}
	
	public DBConnectionInfo(String dbUrl, String dbUsername, String dbPassword,
			String dbDriverClass) {
		super();
		this.dbUrl = dbUrl;
		this.dbUsername = dbUsername;
		this.dbPassword = dbPassword;
		this.dbDriverClass = dbDriverClass;
		this.setEmbeddedDatabaseLocation("");
	}

	public String getDbUrl() {
		return dbUrl;
	}

	public void setDbUrl(String dbUrl) {
		this.dbUrl = dbUrl;
	}

	public String getDbUsername() {
		return dbUsername;
	}

	public void setDbUsername(String dbUsername) {
		this.dbUsername = dbUsername;
	}

	public String getDbPassword() {
		return dbPassword;
	}

	public void setDbPassword(String dbPassword) {
		this.dbPassword = dbPassword;
	}

	public String getDbDriverClass() {
		return dbDriverClass;
	}

	public void setDbDriverClass(String dbDriverClass) {
		this.dbDriverClass = dbDriverClass;
	}

	public void setEmbeddedDatabaseLocation(String embeddedDatabaseLocation) {
		this.embeddedDatabaseLocation = embeddedDatabaseLocation;
	}

	public String getEmbeddedDatabaseLocation() {
		return embeddedDatabaseLocation;
	}
	
	
	

}
