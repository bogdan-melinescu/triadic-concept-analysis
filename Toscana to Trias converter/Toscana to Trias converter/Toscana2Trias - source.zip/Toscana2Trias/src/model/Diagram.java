package model;

import java.util.HashMap;
import java.util.Map;

/**
 * DTO holding information about scales created with Elba
 */
public class Diagram {
	/** Title of the diagram comprising the scales as defined in the context-file */
	private String diagramTitle;
	
	/** Scales for a diagram*/
	private Map<String, ScalingInfo> scales;
	
	public Diagram(){
		scales = new HashMap<String, ScalingInfo>();
	}

	public String getDiagramTitle() {
		return diagramTitle;
	}

	public void setDiagramTitle(String diagramTitle) {
		this.diagramTitle = diagramTitle;
	}

	public Map<String, ScalingInfo> getScales() {
		return scales;
	}

	public void setScales(Map<String, ScalingInfo> scales) {
		this.scales = scales;
	}
	
	public void putScale(String key, ScalingInfo scalingInfo){
		scales.put(key, scalingInfo);
	}
	
	public String toString(){
		return diagramTitle;
	}
	
	
	

}
