package ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import model.Diagram;
import model.ScalingInfo;
import controller.TriasPreprocessorController;

/**
 * This code was edited or generated using CloudGarden's Jigloo SWT/Swing GUI
 * Builder, which is free for non-commercial use. If Jigloo is being used
 * commercially (ie, by a corporation, company or business for any purpose
 * whatever) then you should purchase a license for each developer using Jigloo.
 * Please visit www.cloudgarden.com for details. Use of Jigloo implies
 * acceptance of these licensing terms. A COMMERCIAL LICENSE HAS NOT BEEN
 * PURCHASED FOR THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED LEGALLY FOR
 * ANY CORPORATE OR COMMERCIAL PURPOSE.
 */
public class TriasUI extends javax.swing.JFrame implements ActionListener,
		ItemListener {

	private static final String FRAME_TITLE = "UBB-Trias Preprocessor";

	private static final long serialVersionUID = 1L;
	private JLabel jLabel1;
	private JLabel jLabel2;
	private JLabel jLabel4;
	private JLabel jLabel5;
	private JTextField separatorText;
	private JLabel jLabel6;
	private JButton generateFileBtn;
	private JLabel jLabel3;
	private JComboBox diagramsCombo;
	private JList conditionsList;
	private DefaultListModel conditionsModelList;
	private JList attributesList;
	private DefaultListModel attributesModelList;
	private JScrollPane conditionsScrollPane;
	private JScrollPane attributesScrollPane;
	private JTextField outputFileTextBox;
	private JLabel outputFileLabel;
	private JButton clearConditionsButton;
	private JButton deleteConditionsButton;
	private JButton clearAttributesButton;
	private JButton deleteAttributesButton;
	private JButton generateOALButton;
	private JButton addToConditionsBtn;
	private JButton addToAttributesBtn;
	private JList columnsList;
	private DefaultListModel columnsModelList;
	private JScrollPane columnsScrollPanel;
	private DefaultComboBoxModel diagramsComboModel;

	private TriasPreprocessorController cntr;
	private List<Diagram> diagrams;

	public TriasUI() {
		super(FRAME_TITLE);
		cntr = new TriasPreprocessorController();
		diagrams = cntr.importScales();
		initGUI();
	}

	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			this.setPreferredSize(new java.awt.Dimension(600, 621));
			getContentPane().setLayout(null);
			{
				jLabel1 = new JLabel();
				getContentPane().add(jLabel1);
				jLabel1.setText(FRAME_TITLE);
				jLabel1.setBounds(219, 12, 306, 48);
				jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 20));
			}
			{
				jLabel2 = new JLabel();
				getContentPane().add(jLabel2);
				jLabel2.setText("Diagrams");
				jLabel2.setBounds(49, 66, 102, 16);
			}
			{
				jLabel4 = new JLabel();
				getContentPane().add(jLabel4);
				jLabel4.setText("Selected Attributes");
				jLabel4.setBounds(377, 133, 109, 16);
			}
			{
				jLabel5 = new JLabel();
				getContentPane().add(jLabel5);
				jLabel5.setText("Selected Conditions");
				jLabel5.setBounds(375, 320, 162, 16);
			}
			{
				columnsScrollPanel = new JScrollPane();
				getContentPane().add(columnsScrollPanel);
				columnsScrollPanel.setBounds(49, 164, 220, 315);
				{
					columnsModelList = new DefaultListModel();
					columnsList = new JList();
					columnsScrollPanel.setViewportView(columnsList);
					columnsList.setModel(columnsModelList);
				}
			}
			{
				addToAttributesBtn = new JButton();
				getContentPane().add(addToAttributesBtn);
				addToAttributesBtn.setText("attr >>");
				addToAttributesBtn.setBounds(281, 205, 85, 28);
				addToAttributesBtn.addActionListener(this);
			}
			{
				addToConditionsBtn = new JButton();
				getContentPane().add(addToConditionsBtn);
				addToConditionsBtn.setText("cond >>");
				addToConditionsBtn.setBounds(281, 377, 83, 25);
				addToConditionsBtn.addActionListener(this);
			}
			{
				attributesScrollPane = new JScrollPane();
				getContentPane().add(attributesScrollPane);
				attributesScrollPane.setBounds(375, 165, 161, 106);
				{
					attributesModelList = new DefaultListModel();
					attributesList = new JList();
					attributesScrollPane.setViewportView(attributesList);
					attributesList.setModel(attributesModelList);
					attributesList.setBounds(380, 165, 158, 103);
				}
			}
			{
				conditionsScrollPane = new JScrollPane();
				getContentPane().add(conditionsScrollPane);
				conditionsScrollPane.setBounds(375, 342, 160, 110);
				{
					conditionsModelList = new DefaultListModel();
					conditionsList = new JList();
					conditionsScrollPane.setViewportView(conditionsList);
					conditionsList.setModel(conditionsModelList);
					conditionsList.setBounds(379, 319, 157, 109);
				}
			}
			{
				diagramsComboModel = new DefaultComboBoxModel();
				populateDiagramsCombo();
				diagramsCombo = new JComboBox();
				getContentPane().add(diagramsCombo);
				diagramsCombo.setModel(diagramsComboModel);
				diagramsCombo.setBounds(49, 94, 223, 22);
				diagramsCombo.addItemListener(this);
				itemStateChanged(null);
			}
			{
				jLabel3 = new JLabel();
				getContentPane().add(jLabel3);
				jLabel3.setText("Scales");
				jLabel3.setBounds(49, 133, 95, 16);
			}
			{
				generateFileBtn = new JButton();
				getContentPane().add(generateFileBtn);
				generateFileBtn.setText("Generate Trias File");
				generateFileBtn.setBounds(375, 521, 161, 22);
				generateFileBtn.addActionListener(this);
			}
			{
				jLabel6 = new JLabel();
				getContentPane().add(jLabel6);
				jLabel6.setText("File Separator:");
				jLabel6.setBounds(49, 523, 137, 16);
			}
			{
				separatorText = new JTextField();
				getContentPane().add(separatorText);
				separatorText.setText(",");
				separatorText.setBounds(145, 521, 122, 22);
			}
			{
				generateOALButton = new JButton();
				getContentPane().add(generateOALButton);
				generateOALButton.setText("Generate OAL file");
				generateOALButton.setBounds(375, 554, 161, 21);
				generateOALButton.addActionListener(this);
			}
			{
				deleteAttributesButton = new JButton();
				getContentPane().add(deleteAttributesButton);
				deleteAttributesButton.setText("Delete");
				deleteAttributesButton.setBounds(375, 277, 78, 21);
				deleteAttributesButton.addActionListener(this);
			}
			{
				clearAttributesButton = new JButton();
				getContentPane().add(clearAttributesButton);
				clearAttributesButton.setText("Clear");
				clearAttributesButton.setBounds(458, 277, 78, 21);
				clearAttributesButton.addActionListener(this);
			}
			{
				deleteConditionsButton = new JButton();
				getContentPane().add(deleteConditionsButton);
				deleteConditionsButton.setText("Delete");
				deleteConditionsButton.setBounds(375, 458, 78, 21);
				deleteConditionsButton.addActionListener(this);
			}
			{
				clearConditionsButton = new JButton();
				getContentPane().add(clearConditionsButton);
				clearConditionsButton.setText("Clear");
				clearConditionsButton.setBounds(458, 458, 78, 21);
				clearConditionsButton.addActionListener(this);
			}
			{
				outputFileLabel = new JLabel();
				getContentPane().add(outputFileLabel);
				outputFileLabel.setText("Output file:");
				outputFileLabel.setBounds(49, 491, 79, 14);
			}
			{
				outputFileTextBox = new JTextField();
				getContentPane().add(outputFileTextBox);
				outputFileTextBox.setBounds(146, 488, 121, 21);
			}
			pack();
			this.setSize(600, 621);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void populateDiagramsCombo() {
		diagramsComboModel.removeAllElements();
		for (Diagram diagram : diagrams) {
			diagramsComboModel.addElement(diagram);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == addToAttributesBtn) { // the button for adding a scale to the attributes set
			List<ScalingInfo> removableObjects = new ArrayList<ScalingInfo>();
			int[] indices = columnsList.getSelectedIndices();
			for (int index = 0; index < indices.length; index++) {
				ScalingInfo selected = (ScalingInfo) columnsModelList
						.getElementAt(indices[index]);
				if (notAddedBefore(selected)) {
					attributesModelList.addElement(selected);
					removableObjects.add(selected);
				}
			}

			for (ScalingInfo info : removableObjects) {
				columnsModelList.removeElement(info);
			}

		}
		if (e.getSource() == addToConditionsBtn) { // the button for adding a scale to the conditions set
			int[] indices = columnsList.getSelectedIndices();
			List<ScalingInfo> removableObjects = new ArrayList<ScalingInfo>();
			for (int index = 0; index < indices.length; index++) {
				ScalingInfo selected = (ScalingInfo) columnsModelList
						.getElementAt(indices[index]);
				if (notAddedBefore(selected)) {
					conditionsModelList.addElement(selected);
					removableObjects.add(selected);
				}
			}
			for (ScalingInfo info : removableObjects) {
				columnsModelList.removeElement(info);
			}

		}

		if (e.getSource() == generateFileBtn) { // the button for generating the Trias-specific file
			if (attributesModelList.size() > 0
					&& conditionsModelList.size() > 0) {
				List<ScalingInfo> selectedAttributes = new ArrayList<ScalingInfo>();
				List<ScalingInfo> selectedConditions = new ArrayList<ScalingInfo>();
				getAttributesAndConditionsFromListBoxes(selectedAttributes,
						selectedConditions);

				String separator = separatorText.getText();

				if (separator != null && !separator.equals("")) {
					try {
						cntr.generateTriasFile(selectedAttributes,
								selectedConditions, separator,
								outputFileTextBox.getText());
					} catch (Exception ex) {
						JOptionPane.showMessageDialog(TriasUI.this,
								"An error has occured: " + ex, "Error",
								JOptionPane.ERROR_MESSAGE);
						return;
					}
				} else {
					JOptionPane.showMessageDialog(TriasUI.this,
							"You must pick a separator!!!", "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}
			}

			JOptionPane.showMessageDialog(TriasUI.this,
					"File generation: \n DONE", "Info",
					JOptionPane.INFORMATION_MESSAGE);
			return;
		}
		if (e.getSource() == generateOALButton) { // generate Conexp-specific file
			if (attributesModelList.size() > 0
					&& conditionsModelList.size() > 0) {
				List<ScalingInfo> selectedAttributes = new ArrayList<ScalingInfo>();
				List<ScalingInfo> selectedConditions = new ArrayList<ScalingInfo>();
				getAttributesAndConditionsFromListBoxes(selectedAttributes,
						selectedConditions);

				try {
					cntr.generateOALFile(selectedAttributes,
							selectedConditions, outputFileTextBox.getText());
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(TriasUI.this,
							"An error has occured: " + ex, "Error",
							JOptionPane.ERROR_MESSAGE);
				}
			}

			JOptionPane.showMessageDialog(TriasUI.this,
					"File generation: \n DONE", "Info",
					JOptionPane.INFORMATION_MESSAGE);
			return;
		}
		if (e.getSource() == deleteAttributesButton) { //remove scales from the attributes set
			int[] selectedIndices = attributesList.getSelectedIndices();
			for (int i = selectedIndices.length - 1; i >= 0; i--) {
				attributesModelList.removeElementAt(i);
			}
			Diagram diagram = (Diagram) diagramsCombo.getSelectedItem();
			populateScalesList(diagram);
			return;
		}
		if (e.getSource() == clearAttributesButton) { //remove all scales from the attributes set
			attributesModelList.removeAllElements();
			Diagram diagram = (Diagram) diagramsCombo.getSelectedItem();
			populateScalesList(diagram);
			return;
		}
		if (e.getSource() == deleteConditionsButton) { //remove scales from the conditions set
			int[] selectedIndices = conditionsList.getSelectedIndices();
			for (int i = selectedIndices.length - 1; i >= 0; i--) {
				conditionsModelList.removeElementAt(i);
			}
			Diagram diagram = (Diagram) diagramsCombo.getSelectedItem();
			populateScalesList(diagram);
			return;
		}
		if (e.getSource() == clearConditionsButton) { //remove all scales from the conditions set
			conditionsModelList.removeAllElements();
			Diagram diagram = (Diagram) diagramsCombo.getSelectedItem();
			populateScalesList(diagram);
			return;
		}
	}

	private void getAttributesAndConditionsFromListBoxes(
			List<ScalingInfo> selectedAttributes,
			List<ScalingInfo> selectedConditions) {
		for (int i = 0; i < attributesModelList.getSize(); i++) {
			selectedAttributes.add((ScalingInfo) attributesModelList.get(i));
		}
		for (int i = 0; i < conditionsModelList.getSize(); i++) {
			selectedConditions.add((ScalingInfo) conditionsModelList.get(i));
		}
	}

	private boolean notAddedBefore(ScalingInfo selected) {
		for (int i = 0; i < attributesModelList.getSize(); i++) {
			if (selected.equals((ScalingInfo) attributesModelList.get(i))) {
				return false;
			}
		}
		for (int i = 0; i < conditionsModelList.getSize(); i++) {
			if (selected.equals((ScalingInfo) conditionsModelList.get(i))) {
				return false;
			}
		}
		return true;
	}

	@Override
	public void itemStateChanged(ItemEvent arg0) {
		int index = diagramsCombo.getSelectedIndex();
		if (index >= 0) {
			Diagram diagram = (Diagram) diagramsComboModel.getElementAt(index);
			populateScalesList(diagram);
		}
	}

	private void populateScalesList(Diagram diagram) {
		columnsModelList.clear();
		for (String scaleInfo : diagram.getScales().keySet()) {
			ScalingInfo scalingInfo = diagram.getScales().get(scaleInfo);
			if (notAddedBefore(scalingInfo)) {
				columnsModelList.addElement(scalingInfo);
			}
		}

	}

}
